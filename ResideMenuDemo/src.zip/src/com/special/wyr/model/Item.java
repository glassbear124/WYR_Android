package com.special.wyr.model;


public class Item {
    public String title;
    public String comment;
    public int    avatarId;
    public String rightStr;
    public void Item() {

    }
}
